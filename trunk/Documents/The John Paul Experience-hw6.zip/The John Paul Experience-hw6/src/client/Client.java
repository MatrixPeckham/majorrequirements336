package client;

import java.io.File;
import java.net.Socket;

/**
 * Main networking class for the client.
 * @author Bill
 *
 */
//TODO finish this class all methods marked with TODO need
//TODO server classes the rest are stubs that need socket interaction
public class Client implements Runnable{
	/**Socket for communication with server*/
	private Socket s;
//TODO public Schedule generateSchedule() {return null;}
	public File getFile(String str) {return null;}
	public int uploadFile(File file, String str) {return 0;}
//TODO	public boolean addCourse(Course c, String str) {return false;}
//TODO	public Course loadCourse(String str) {return null;}
	public boolean removeCourse(String str) {return false;}
//TODO	public boolean editCourse(Course c) {return false;}
//TODO	public Major loadMajor(String str) {return null;}
//TODO	public void addMajor(Major m) {}
//TODO	public boolean editMajor(Major m) {return false;}
	public boolean removeMajor(String str) {return false;}
//TODO	public boolean addRequirement(Requirement r, String str) {return false;}
	public boolean removeRequirement(String str1, String str2){return false;}
	public int login(String usr,String pass) {return 3;}
	public boolean logout() {return false;}
//TODO	public Vector<Requirements> getRequirements() {return null;}
	public int getCreditsRemaining() {return 0;}
//TODO	public void addDepartment(String, Department) {}
	public void removeDepartment (String str) {}
//TODO	public void editDepartment(String str, Department d) {}
//TODO	public Vector<Department> getDepartments() {return null;}
//TODO	public Department getDepartment(String str) {return null;}
//TODO	public Vector<Course> getDepartmentCourses(String) {return null;} 

	@Override
	//TODO finish
	public void run() {
		if(s==null){
			return;
		}
	}
}